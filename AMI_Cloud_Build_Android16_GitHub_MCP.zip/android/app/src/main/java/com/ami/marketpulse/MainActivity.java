package com.ami.marketpulse;

import android.app.Activity;
import android.Manifest;
import android.os.Build;
import android.os.Bundle;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceResponse;
import android.webkit.WebResourceRequest;
import java.io.InputStream;
import android.webkit.WebChromeClient;
import android.content.Intent;
import android.view.WindowInsets;
import android.view.View;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xff080e1b);
        getWindow().setNavigationBarColor(0xff080e1b);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl();
                if ("https".equals(u.getScheme()) && "appassets.androidplatform.net".equals(u.getHost()) && u.getPath().startsWith("/assets/")) {
                    try {
                        String asset=u.getPath().substring("/assets/".length());
                        if (!asset.equals("index.html") && !asset.equals("ami_icon.png")) return null;
                        InputStream in=getAssets().open(asset);
                        return new WebResourceResponse(asset.endsWith(".html")?"text/html":"image/png", "UTF-8", in);
                    } catch(Exception ignored){return null;}
                }
                return super.shouldInterceptRequest(view,request);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("https://")) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true; }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AppBridge(), "Android");
        // Android 15/16 enforce edge-to-edge layout for recent target SDKs.
        // Respect safe insets so navigation and content remain touchable.
        if (Build.VERSION.SDK_INT >= 30) {
            web.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        setContentView(web);
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        BriefingReceiver.schedule(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 17);
        }
    }
    public final class AppBridge {
        @JavascriptInterface public void scheduleNotifications(String morning, String evening, boolean enabled) {
            getSharedPreferences("ami",Context.MODE_PRIVATE).edit().putString("morning",morning).putString("evening",evening).putBoolean("enabled",enabled).apply();
            BriefingReceiver.schedule(MainActivity.this);
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
