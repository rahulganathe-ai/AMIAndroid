package com.ami.marketpulse;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.TimeZone;

public class BriefingReceiver extends BroadcastReceiver {
    private static final String CHANNEL="ami_briefings";
    public static void schedule(Context c) {
        SharedPreferences s=c.getSharedPreferences("ami", Context.MODE_PRIVATE);
        AlarmManager manager=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (manager==null) return;
        String[] slots={s.getString("morning","08:45"),s.getString("evening","18:00")};
        boolean enabled=s.getBoolean("enabled",true);
        for (int i=0;i<2;i++) {
            Intent intent=new Intent(c,BriefingReceiver.class).putExtra("slot",i);
            PendingIntent pi=PendingIntent.getBroadcast(c,800+i,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if (!enabled) { manager.cancel(pi);continue; }
            try {
                String[] hm=slots[i].split(":");
                Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"));
                cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(hm[0]));cal.set(Calendar.MINUTE,Integer.parseInt(hm[1]));
                cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
                if (cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_MONTH,1);
                // Inexact alarms respect Android background scheduling limits; not guaranteed to the minute.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
            } catch(Exception ignored) { }
        }
    }
    @Override public void onReceive(Context c, Intent intent) {
        int slot=intent.getIntExtra("slot",0);schedule(c);
        PendingResult result=goAsync();
        new Thread(()->{
            String summary="Open AMI for the latest verified market briefing.";
            try {
                // Endpoint and token stay in browser storage, not native prefs. Notifications therefore
                // avoid assuming that data has refreshed without a secure background sync service.
                // A production deployment should persist a read-only token through encrypted app storage.
                String[] cats={"Nifty","MLD / NCD","RBI Policy","Mutual Funds","Commodities"};
                summary="Latest market signals: open AMI to refresh verified data.";
                NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
                if(nm==null)return;
                if(Build.VERSION.SDK_INT>=26){nm.createNotificationChannel(new NotificationChannel(CHANNEL,"AMI market briefings",NotificationManager.IMPORTANCE_DEFAULT));}
                Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
                b.setSmallIcon(android.R.drawable.ic_popup_reminder)
                 .setContentTitle(slot==0?"AMI • Morning Market Briefing":"AMI • Evening Market Briefing")
                 .setContentText(summary).setStyle(new Notification.BigTextStyle().bigText(summary))
                 .setAutoCancel(true);
                Intent open=new Intent(c,MainActivity.class);
                b.setContentIntent(PendingIntent.getActivity(c,92,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
                nm.notify(100+slot,b.build());
            } catch(Exception ignored){}finally{result.finish();}
        }).start();
    }
}
