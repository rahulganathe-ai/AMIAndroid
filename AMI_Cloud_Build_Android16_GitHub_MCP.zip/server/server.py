#!/usr/bin/env python3
"""AMI personal-use MCP + read-only dashboard server. Python 3.10+, standard library.
Deploy behind HTTPS reverse proxy. API has two separate tokens; do not expose localhost insecurely.
"""
import os, json, sys, ssl, re, time, hashlib, threading, urllib.request, urllib.parse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parent
STATE_FILE=Path(os.getenv('AMI_STATE_FILE',str(ROOT/'ami-state.json')))
READ_TOKEN=os.getenv('AMI_READ_TOKEN','')
ADMIN_TOKEN=os.getenv('AMI_ADMIN_TOKEN','')
PORT=int(os.getenv('PORT','8080'))
HOST=os.getenv('HOST','127.0.0.1')
if not READ_TOKEN or not ADMIN_TOKEN or READ_TOKEN==ADMIN_TOKEN:
    print('Set distinct AMI_READ_TOKEN and AMI_ADMIN_TOKEN environment variables.',file=sys.stderr);sys.exit(1)
CATS=['Nifty','Structured Products (MLD/NCD)','RBI Policy','Mutual Funds','Commodities']
FEEDS=[('Economic Times Markets','https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms'),('Economic Times Stocks','https://economictimes.indiatimes.com/markets/stocks/rssfeeds/2146842.cms'),('RBI Press Releases','https://www.rbi.org.in/pressreleases_rss.xml'),('SEBI Press Releases','https://www.sebi.gov.in/sebirss.xml'),('Mint Markets','https://www.livemint.com/rss/marketsRSS'),('Business Standard Markets','https://www.business-standard.com/rss/markets-106.rss')]
POS=['rise','rises','upbeat','gain','gains','growth','surge','surges','boost','strong','higher','rally','profit rises','record high','recovery','improve']
NEG=['fall','falls','decline','loss','losses','weak','lower','slump','cut','cuts','selloff','crash','inflation','fraud','downgrade','deficit','risk']
DEFAULT={'updated_at':None,'settings':{'morning':'08:45','evening':'18:00','refresh_interval':15,'filters':{'minRvol':1.5,'minAdx':25,'minRoe':12},'forex':{'currencies':['USD','EUR','GBP','JPY','CNY'],'impacts':['High','Medium']}},'watchlist':[],'stock_inputs':[]}
lock=threading.RLock();feed_cache={'at':0,'result':{}}
forex_cache={'at':0,'events':[],'updated_at':None,'error':None}
FOREX_URL='https://nfs.faireconomy.media/ff_calendar_thisweek.json'
FOREX_HOME='https://www.forexfactory.com/calendar'
def state():
    try:return {**DEFAULT,**json.loads(STATE_FILE.read_text(encoding='utf8'))}
    except:return json.loads(json.dumps(DEFAULT))
def save(data):
    data['updated_at']=datetime.now(timezone.utc).isoformat()
    tmp=STATE_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2));tmp.replace(STATE_FILE)
def classify(t):
    text=t.lower()
    if any(x in text for x in ['rbi','repo rate','monetary policy','reserve bank','inflation target']):return 'RBI Policy'
    if any(x in text for x in ['mld','market linked debenture','non-convertible debenture','ncd','structured product']):return 'Structured Products (MLD/NCD)'
    if any(x in text for x in ['mutual fund','sip','asset management','amc','nav']):return 'Mutual Funds'
    if any(x in text for x in ['gold','silver','crude','oil','commodity','commodities','copper','metals']):return 'Commodities'
    return 'Nifty'
def headline_conclusion(title, category):
    """Cautious one-line interpretation of a headline, not the article body or a trade signal."""
    title=str(title or '')[:300]
    lower=title.lower()
    def has(*words):
        return any(re.search(r'\b'+re.escape(w)+r'\b',lower) for w in words)
    if category=='RBI Policy' and has('repo','rate','interest') and has('cuts','cut','reduces','reduced','lowers','lowered'):
        return {'bias':'Potentially positive','conclusion':'A rate cut may reduce borrowing costs and support rate-sensitive sectors; verify the policy and expected market reaction.'}
    if category=='RBI Policy' and has('repo','rate','interest') and has('hikes','hike','raises','raised','increases','increased'):
        return {'bias':'Potentially negative','conclusion':'Higher interest rates may pressure borrowers and rate-sensitive stocks; the market response depends on expectations.'}
    if has('inflation','cpi') and has('cools','eases','slows','falls','declines'):
        return {'bias':'Potentially positive','conclusion':'Cooling inflation may reduce pressure on interest rates; confirm the released figures versus forecasts.'}
    if has('inflation','cpi') and has('surges','rises','jumps','accelerates','higher'):
        return {'bias':'Potentially negative','conclusion':'Higher inflation may raise interest-rate concerns; verify the actual reading and consensus expectation.'}
    if category=='Commodities' and has('crude','oil') and has('surge','surges','rise','rises','jump','jumps','higher','gain','gains'):
        return {'bias':'Mixed','conclusion':'Higher oil prices can lift costs for importers while helping some producers; sector impact depends on prices and margins.'}
    if category=='Commodities' and has('crude','oil') and has('fall','falls','slips','drops','declines','lower'):
        return {'bias':'Mixed','conclusion':'Lower oil prices may help importers and ease cost pressure, but can weigh on producers.'}
    pos=sum(bool(re.search(r'\b'+re.escape(w)+r'\b',lower)) for w in ('surge','surges','rally','rallies','gain','gains','rises','growth','improves','strong','record','beats','higher','upgrades'))
    neg=sum(bool(re.search(r'\b'+re.escape(w)+r'\b',lower)) for w in ('falls','declines','slumps','loss','losses','drops','weak','cuts','downgrades','misses','lower','risk','fraud'))
    if pos>neg:
        return {'bias':'Positive headline','conclusion':'This headline suggests a favorable development; confirm its scale and price/volume reaction before acting.'}
    if neg>pos:
        return {'bias':'Negative headline','conclusion':'This headline suggests possible downside pressure; confirm the facts and market reaction before acting.'}
    return {'bias':'Unclear','conclusion':'No reliable market direction can be inferred from this headline alone; read the source before making a decision.'}

def get_news():
    with lock:
        if time.monotonic()-feed_cache['at']<600:return feed_cache['result']
    grouped={cat:[] for cat in CATS};seen=set()
    def retrieve(feed):
        name,url=feed
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'AMI Personal Market RSS Reader/1.0'})
            with urllib.request.urlopen(req,timeout=5) as r: xml=r.read(1200000)
            root=ET.fromstring(xml)
            return name, [( (x.findtext('title') or '').strip(), (x.findtext('link') or '').strip() ) for x in root.findall('.//item')[:45]]
        except Exception as ex:
            print('RSS unavailable',name,str(ex)[:75],file=sys.stderr)
            return name,[]
    # Concurrent fetch caps wait at about one feed timeout instead of serial timeouts.
    with ThreadPoolExecutor(max_workers=max(1,len(FEEDS))) as pool:
        for name,items in pool.map(retrieve,FEEDS):
            for title,link in items:
                key=re.sub(r'\W+','',title.lower())
                if not title or not link.startswith('https://') or key in seen:continue
                seen.add(key);cat=classify(title)
                if len(grouped[cat])<5:grouped[cat].append({'title':title,'url':link,'source':name,**headline_conclusion(title,cat)})
    news={}
    for cat,items in grouped.items():
        text=' '.join(i['title'] for i in items).lower();plus=sum(text.count(w) for w in POS);minus=sum(text.count(w) for w in NEG)
        news[cat]={'sentiment':('Bullish' if plus>minus else 'Bearish' if minus>plus else 'Neutral') if items else 'Unavailable','headlines':items,'conclusion':('Overall headline tone is more positive; a price move is not guaranteed.' if plus>minus else 'Overall headline tone is more negative; a price move is not guaranteed.' if minus>plus else 'Mixed or insufficient headline evidence; no clear market direction.') if items else 'No current headlines available; market impact cannot be assessed.'}
    with lock:feed_cache.update(at=time.monotonic(),result=news)
    return news
def normalize_forex_events(rows):
    """Normalize Forex Factory's public weekly export; never claim it includes actuals."""
    if not isinstance(rows,list):raise ValueError('Unexpected Forex Factory response')
    out=[]
    for row in rows[:500]:
        if not isinstance(row,dict):continue
        try:
            date=datetime.fromisoformat(str(row.get('date','')))
            if date.tzinfo is None:continue
            title=str(row.get('title','')).strip()[:150]
            currency=str(row.get('country','')).upper()[:5]
            impact=str(row.get('impact','')).title()[:10]
            if not title or not re.fullmatch(r'[A-Z]{3}',currency) or impact not in ('High','Medium','Low','Holiday'):continue
            out.append({'title':title,'currency':currency,'impact':impact,'time_ist':date.astimezone(ZoneInfo('Asia/Kolkata')).isoformat(timespec='minutes'),
                        'time_utc':date.astimezone(timezone.utc).isoformat(timespec='minutes'),
                        'forecast':str(row.get('forecast',''))[:45],'previous':str(row.get('previous',''))[:45],
                        'source':'Forex Factory','source_url':FOREX_HOME,
                        'conclusion':('High-impact release may cause volatility; direction depends on actual values versus market forecasts.' if impact=='High' else 'Possible market reaction; direction depends on actual values versus market forecasts.')})
        except (TypeError,ValueError,OverflowError):continue
    out.sort(key=lambda x:x['time_utc'])
    return out

def get_forex_calendar(filters=None):
    """Fetch at most once an hour per server process; honour export rate limits."""
    with lock:
        if not forex_cache['at'] or time.monotonic()-forex_cache['at']>=3600:
            forex_cache['at']=time.monotonic()  # rate-limit even on failed requests
            try:
                req=urllib.request.Request(FOREX_URL,headers={'User-Agent':'AMI Personal Research Calendar/1.0','Accept':'application/json'})
                with urllib.request.urlopen(req,timeout=7) as r:
                    blob=r.read(1000000)
                if not blob.lstrip().startswith(b'['):raise ValueError('Export unavailable / request limited')
                forex_cache['events']=normalize_forex_events(json.loads(blob))
                forex_cache['updated_at']=datetime.now(timezone.utc).isoformat()
                forex_cache['error']=None
            except Exception as ex:
                forex_cache['error']='Forex Factory calendar feed temporarily unavailable'
                print('Forex Factory error:',str(ex)[:120],file=sys.stderr)
        events=list(forex_cache['events'])
        error=forex_cache['error']
        updated_at=forex_cache['updated_at']
    filt=filters or {}
    currencies=[str(c).upper() for c in filt.get('currencies',[]) if isinstance(c,str)]
    impacts=[str(c).title() for c in filt.get('impacts',[]) if isinstance(c,str)]
    if currencies:events=[ev for ev in events if ev['currency'] in currencies]
    if impacts:events=[ev for ev in events if ev['impact'] in impacts]
    now=datetime.now(timezone.utc)
    upcoming=[ev for ev in events if datetime.fromisoformat(ev['time_utc'])>=now]
    # On weekends or after the week's releases, show latest recent events labelled as past, not as upcoming.
    if not upcoming:
        recent=[ev for ev in events if now-timedelta(hours=48)<=datetime.fromisoformat(ev['time_utc'])<now]
        upcoming=list(reversed(recent))
    return {'events':upcoming[:30], 'timezone':'Asia/Kolkata', 'updated_at':updated_at,
            'source':'Forex Factory weekly calendar export', 'source_url':FOREX_HOME,
            'feed_available':not bool(error), 'error':error,
            'note':'Forecast / previous only. Released actuals are not supplied by the weekly export. Times shown in IST.'}

def valid_stock(s,criteria):
    required=['symbol','company','source_url','market_date','rsi','adx','relative_volume','roe','ema_fast','ema_slow','news_score']
    if not isinstance(s,dict) or any(k not in s for k in required):return None
    try:
        if not str(s['source_url']).startswith('https://'):return None
        d=datetime.fromisoformat(str(s['market_date'])[:10]);age=(datetime.now(timezone.utc).date()-d.date()).days
        if age<0 or age>5:return None
        rsi=float(s['rsi']);adx=float(s['adx']);rvol=float(s['relative_volume']);roe=float(s['roe']);fast=float(s['ema_fast']);slow=float(s['ema_slow']);news=float(s['news_score'])
        if not 0<=rsi<=100 or rvol<=0 or not 0<=adx<=100:return None
        filters=criteria
        volume=rvol>=float(filters.get('minRvol',1.5));trend=adx>=float(filters.get('minAdx',25));quality=roe>=float(filters.get('minRoe',12))
        if volume and trend and quality and fast>slow and rsi>55 and news>=0:signal='BUY'
        elif volume and trend and fast<slow and rsi<45 and news<=0:signal='SELL'
        else:signal='WAIT'
        score=(2 if volume else 0)+(2 if trend else 0)+(2 if quality else 0)+min(rvol,4)+min(adx/20,3)+(1 if signal!='WAIT' else 0)
        return {'symbol':str(s['symbol'])[:20],'company':str(s['company'])[:80],'signal':signal,'relative_volume':round(rvol,2),'rsi':round(rsi,1),'roe':round(roe,1),'reason':f'{signal}: RVOL {rvol:.1f}×; ADX {adx:.0f}; trend '+('up' if fast>slow else 'down')+f'; source {str(s["market_date"])[:10]}','source_url':s['source_url'],'market_date':str(s['market_date'])[:10],'score':score}
    except (TypeError,ValueError,OverflowError):return None
def dashboard():
    s=state();c=s['settings'].get('filters',{})
    stocks=[v for v in (valid_stock(x,c) for x in s.get('stock_inputs',[])) if v]
    stocks.sort(key=lambda x:(x['signal']=='WAIT',-x['score']))
    return {'updated_at':datetime.now(timezone.utc).isoformat(),'news':get_news(),'forex_calendar':get_forex_calendar(s['settings'].get('forex',{})),'stocks':stocks[:5],'watchlist':s['watchlist'],'settings':s['settings'],'stock_data_status':'connected' if stocks else 'no_current_verified_inputs'}
def get_revision():
    """Version for MCP edits and cached source updates; cheap enough for foreground polling.

    Not market-data ticks. Reading this endpoint DOES NOT reload upstream publishers.
    """
    s=state()
    with lock:
        feed_at=feed_cache['at']
        forex_at=forex_cache['at']
        feed_updated=bool(feed_cache['result'])
        forex_updated=forex_cache['updated_at']
    raw=json.dumps([s.get('updated_at'),feed_at,forex_at],separators=(',',':'))
    return {'revision':hashlib.sha256(raw.encode()).hexdigest()[:20],
            'checked_at':datetime.now(timezone.utc).isoformat(),
            'news_cached':feed_updated,
            'forex_fetched_at':forex_updated,
            'market_stream_connected':False,
            'notice':'Checks AMI changes every second while the app is visible; does not mean every source updates each second.'}

TOOLS=[
 {'name':'ami_get_state','description':'Read AMI settings, watchlist and published stock inputs.','inputSchema':{'type':'object','properties':{}}},
 {'name':'ami_set_preferences','description':'Update market briefing schedule and screening thresholds.','inputSchema':{'type':'object','properties':{'morning':{'type':'string'},'evening':{'type':'string'},'refresh_interval':{'type':'integer'},'filters':{'type':'object'}}}},
 {'name':'ami_update_watchlist','description':'Replace AMI tracking symbols.','inputSchema':{'type':'object','properties':{'symbols':{'type':'array','items':{'type':'string'}}},'required':['symbols']}},
 {'name':'ami_publish_stocks','description':'Publish independently sourced, dated candidate metrics. No real-time broker data supplied by server.','inputSchema':{'type':'object','properties':{'stocks':{'type':'array','items':{'type':'object'}}},'required':['stocks']}},
 {'name':'ami_get_dashboard','description':'Read current news, Forex Factory calendar and ranked up-to-five stock signals.','inputSchema':{'type':'object','properties':{}}},
 {'name':'ami_get_forex_calendar','description':'Read filtered Forex Factory weekly economic events with times in Asia/Kolkata; read-only.','inputSchema':{'type':'object','properties':{}}},
 {'name':'ami_set_forex_filters','description':'Edit AMI Forex Factory calendar filters for currencies and impact levels.','inputSchema':{'type':'object','properties':{'currencies':{'type':'array','items':{'type':'string'}},'impacts':{'type':'array','items':{'type':'string'}}}}}
]
def execute(name,args):
    with lock:
        s=state()
        if name=='ami_get_state':return s
        if name=='ami_get_dashboard':return dashboard()
        if name=='ami_get_forex_calendar':return get_forex_calendar(s['settings'].get('forex',{}))
        if name=='ami_set_forex_filters':
            forex=s['settings'].setdefault('forex',{})
            if 'currencies' in args:
                cs=args['currencies']
                if not isinstance(cs,list) or len(cs)>25 or any(not re.fullmatch(r'[A-Za-z]{3}',str(c)) for c in cs):raise ValueError('currencies must be 3-letter currency codes')
                forex['currencies']=list(dict.fromkeys(str(c).upper() for c in cs))
            if 'impacts' in args:
                levels=args['impacts']
                if not isinstance(levels,list) or any(str(c).title() not in ('High','Medium','Low','Holiday') for c in levels):raise ValueError('impacts must be High, Medium, Low or Holiday')
                forex['impacts']=list(dict.fromkeys(str(c).title() for c in levels))
            save(s);return {'ok':True,'forex':forex}
        if name=='ami_update_watchlist':
            syms=args.get('symbols')
            if not isinstance(syms,list) or len(syms)>100:raise ValueError('symbols must be an array up to 100')
            s['watchlist']=[str(t).upper()[:25] for t in syms if str(t).strip()];save(s);return {'ok':True,'watchlist':s['watchlist']}
        if name=='ami_set_preferences':
            for key in ['morning','evening']:
                if key in args:
                    val=str(args[key]);
                    if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',val):raise ValueError(key+' must be HH:MM')
                    s['settings'][key]=val
            if 'refresh_interval' in args:s['settings']['refresh_interval']=max(5,min(60,int(args['refresh_interval'])))
            if 'filters' in args:
                for k in ['minRvol','minAdx','minRoe']:
                    if k in args['filters']:s['settings']['filters'][k]=float(args['filters'][k])
            save(s);return {'ok':True,'settings':s['settings']}
        if name=='ami_publish_stocks':
            stocks=args.get('stocks');
            if not isinstance(stocks,list) or len(stocks)>200:raise ValueError('stocks must be an array up to 200')
            s['stock_inputs']=stocks;save(s);return {'ok':True,'received':len(stocks),'eligible':len([x for x in stocks if valid_stock(x,s['settings']['filters'])])}
        raise ValueError('Unknown tool')
class Handler(BaseHTTPRequestHandler):
    def headers(self,code=200,content='application/json'):
        self.send_response(code);self.send_header('Content-Type',content);self.send_header('Cache-Control','no-store');self.send_header('Access-Control-Allow-Origin','*');self.send_header('Access-Control-Allow-Headers','authorization,content-type,mcp-session-id,mcp-protocol-version');self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS');self.end_headers()
    def output(self,code,p):self.headers(code);self.wfile.write(json.dumps(p,ensure_ascii=False).encode())
    def authorized(self,admin=False):
        token=self.headers.get('Authorization','').removeprefix('Bearer ').strip()
        import hmac
        return bool(token) and hmac.compare_digest(token,ADMIN_TOKEN if admin else READ_TOKEN)
    def do_OPTIONS(self):self.headers(204)
    def do_GET(self):
        if self.path=='/health':return self.output(200,{'ok':True,'service':'AMI'})
        if self.path=='/v1/revision':
            if not self.authorized():return self.output(401,{'error':'Invalid read-only app token'})
            return self.output(200,get_revision())
        if self.path=='/v1/forex-calendar':
            if not self.authorized():return self.output(401,{'error':'Invalid read-only app token'})
            s=state();return self.output(200,get_forex_calendar(s.get('settings',{}).get('forex',{})))
        if self.path=='/v1/dashboard':
            if not self.authorized():return self.output(401,{'error':'Invalid read-only app token'})
            return self.output(200,dashboard())
        self.output(404,{'error':'Not found'})
    def do_POST(self):
        if self.path!='/mcp':return self.output(404,{'error':'Not found'})
        if not self.authorized(admin=True):return self.output(401,{'error':'Admin token required'})
        if int(self.headers.get('Content-Length','0'))>500000:return self.output(413,{'error':'Payload too large'})
        try:
            request=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))));method=request.get('method');id=request.get('id')
            if method=='initialize':result={'protocolVersion':'2025-03-26','capabilities':{'tools':{}},'serverInfo':{'name':'AMI MCP','version':'1.0.0'}}
            elif method=='notifications/initialized':return self.headers(202)
            elif method=='ping':result={}
            elif method=='tools/list':result={'tools':TOOLS}
            elif method=='tools/call':
                p=request.get('params',{});value=execute(p.get('name'),p.get('arguments',{}));result={'content':[{'type':'text','text':json.dumps(value,ensure_ascii=False)}]}
            else:raise ValueError('Unknown MCP method')
            self.output(200,{'jsonrpc':'2.0','id':id,'result':result})
        except Exception as e:self.output(200,{'jsonrpc':'2.0','id':request.get('id') if 'request' in locals() else None,'error':{'code':-32603,'message':str(e)[:200]}})
if __name__=='__main__':
    print(f'AMI server listening on http://{HOST}:{PORT}; serve through HTTPS for remote access.')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
