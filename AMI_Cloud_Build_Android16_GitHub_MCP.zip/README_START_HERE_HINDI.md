# AMI Cloud Build — Android Studio के बिना APK बनाएं

**स्थिति:** यह AMI 1.2.1 का Android source + GitHub Actions build workflow है, तैयार APK नहीं। यहाँ Android SDK उपलब्ध नहीं था इसलिए compiled / device-installed result का दावा नहीं किया गया है। APK GitHub Actions पर सफल बिल्ड के *बाद ही* मिलेगा।

## पहले APK बनाइए — https://github.com

1. GitHub पर अपना account sign in कीजिए। एक **private** repository `ami-android` बनाइए। (Repository को public ना रखें; AMI server source में अपने credentials कभी commit न करें।)
2. इस ZIP को Extract करें। `AMI_GitHub_Cloud_Build` फ़ोल्डर के **अंदर की files और directories** (विशेष रूप से `android/` और `.github/workflows/build-ami-apk.yml`) repository में upload/commit कीजिए। केवल ZIP file upload करने से build नहीं चलेगी। Hidden `.github` directory ज़रूर upload होनी चाहिए। यदि web uploader hidden files छोड़ दे, GitHub Desktop या GitHub plugin का प्रयोग करें।
3. Repository में **Actions** → `Build AMI Android APK (Android 16)` → **Run workflow** → **Run workflow** दबाएँ। Push to main से भी workflow शुरू हो सकता है।
4. Run successful (green tick) हो जाने पर उसी run के नीचे **Artifacts** → `AMI-Android16-debug-APK` डाउनलोड कीजिए। ZIP खोलें और उसके अंदर `app-debug.apk` मिलेगा।
5. Android 16 फोन में APK install करें। पुरानी AMI preview APK अगर एक अलग key से signed है, तो `App not installed` संदेश पर *पुरानी preview को uninstall* करना पड़ सकता है; पहले data backup लें। Debug APK केवल private testing के लिए है, production Play Store release नहीं।
6. Build failure होने पर Github Actions के failed step का पूरा error log दें। बिना successful build के APK tested नहीं है।

### अगर आपने ChatGPT से GitHub plugin connect किया है
Plugin से repository लिखने की सुविधा उपलब्ध हो तो AMI project files और workflow repository में push कराने के लिए कह सकते हैं। Connection alone doesn't create an APK: GitHub Actions build must succeed. Plugin permissions may limit write actions.

## Android build configuration
- Android Gradle Plugin `8.11.1`, Gradle `8.13`, Java `17`.
- `compileSdk 36`, `targetSdk 36` (Android 16); `minSdk 24`.
- Package: `com.ami.marketpulse` / App display label: AMI / Version 1.2.1.
- Replaced old AGP 8.9.2 because Android's compatibility table lists max API 35 for AGP 8.9.
- Removed old preview signing key from this package. GitHub produces a separately debug-signed APK.

## बाद में MCP server — https://render.com और https://chatgpt.com

**APK build और MCP hosting अलग काम हैं।** AMI MCP पहले से deploy नहीं है, उसका **public URL / server ID अभी मौजूद नहीं है**।

1. GitHub repo का `server/` folder cloud host पर deploy करना होगा। Example hosting provider: Render (https://render.com). Create Web Service; select the GitHub repository; Root Directory `server`; Runtime Python; Build `python -m compileall -q .`; Start `python server.py`; Host env var `HOST=0.0.0.0`; set two strong DIFFERENT secret values `AMI_READ_TOKEN` और `AMI_ADMIN_TOKEN`. Render provides a URL **after** successful deployment.
2. Test `https://YOUR-SERVER.onrender.com/health` should respond with `ok:true`. This is just a service health test, not proof ChatGPT MCP connectivity.
3. AMI app → Settings & MCP → server base URL (without `/mcp`) and **read-only token**. Admin token must NEVER be entered in the app.
4. On ChatGPT **web**, Settings → Plugins → `+` → Add custom MCP server (if account/workspace permits), enter `https://YOUR-SERVER.onrender.com/mcp`, configure an authentication method ChatGPT supports, review permission warning, create and test the tool list. See https://help.openai.com/en/articles/12584461-connecting-custom-mcp-servers-in-chatgpt.

**Important limitations:** The included Python `server.py` is a *prototype*, not a production-ready or verified ChatGPT MCP integration. It accepts a custom bearer token and implements a minimal JSON-RPC endpoint. ChatGPT may require a different supported auth method (e.g. OAuth) and more protocol handling; this deployment recipe alone does **not** prove the connector will register. Full MCP write-action access depends on ChatGPT plan/workspace permissions. Before production, complete security review, implement secure authentication and durable data persistence. Cloud free-tier may sleep; do not rely on it for guaranteed pre-9am alerts. No licensed streaming market feeds exist in this package.

## Useful official sites
- GitHub: https://github.com
- Build GitHub Actions docs: https://docs.github.com/en/actions
- Android build instructions: https://developer.android.com/build/building-cmdline
- MCP connection help: https://help.openai.com/en/articles/12584461-connecting-custom-mcp-servers-in-chatgpt
- Render: https://render.com

NEVER publish your AMI admin token, app token, signing key, or brokerage credentials in GitHub.
